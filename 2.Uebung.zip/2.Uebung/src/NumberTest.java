public interface NumberTest {
    boolean testNumber(int number);
}
