public interface CalculationOperation {
    Number calc(Number x,Number y);
}

